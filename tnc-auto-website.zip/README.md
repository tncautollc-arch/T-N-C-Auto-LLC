# T N C Auto LLC — Used Car Dealer Website

Modern, mobile‑friendly site with an easy inventory system.

## Quick start (free hosting)
**Netlify (fastest):**
1) Go to netlify.com and log in.
2) Drag and drop this folder into Netlify — it deploys instantly.

**GitHub Pages:**
1) Create a repo and upload these files.
2) In repo settings → Pages → deploy from the `main` branch / root.

## Where to edit
- Business name/phone/address: edit in the HTML files (search for your details).
- Contact email: appears on pages; the contact form uses Formspree.
- Replace `assets/logo.svg` with your actual logo (or add `logo.png` and update the <img> tag src).
- Inventory lives in `data/inventory.json`.

## Manage inventory
Edit `data/inventory.json` and add cars like:
```json
{
  "vin": "3FA6P0H71JR123456",
  "year": 2019,
  "make": "Ford",
  "model": "Fusion",
  "trim": "SE",
  "price": 13990,
  "mileage": 58500,
  "body_type": "Sedan",
  "drivetrain": "FWD",
  "engine": "2.5L I4",
  "transmission": "Automatic",
  "fuel_type": "Gasoline",
  "exterior_color": "Gray",
  "interior_color": "Black",
  "city_mpg": 21,
  "hwy_mpg": 31,
  "images": ["assets/fusion1.jpg","assets/fusion2.jpg"],
  "features": ["Bluetooth","Backup Camera"],
  "description": "Local trade-in, clean title.",
  "location": "14050 Highway Kk, Lebanon, MO 65536"
}
```
Put your photos in `assets/` and reference them in `images`.

## Contact form
- The form uses Formspree. Replace `action="https://formspree.io/f/yourid"` with your endpoint.
- Or use another free form service (Basin, Netlify Forms) or connect to your CRM.

## SEO
- JSON‑LD for AutoDealer on the home page; Vehicle data on detail pages.
- Customizable meta descriptions, robots.txt, and sitemap.xml.

## Notes
- Everything is static and super fast.
- If you want monthly payment calculator or lead routing, you can add it later.
