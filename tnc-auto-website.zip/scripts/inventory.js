
const qs = s => document.querySelector(s);
const results = qs('#results');
const sMake = qs('#f-make'), sModel = qs('#f-model'), sBody = qs('#f-body');
const nPriceMin = qs('#f-price-min'), nPriceMax = qs('#f-price-max');
const nMileageMax = qs('#f-mileage-max'), yMin = qs('#f-year-min'), yMax = qs('#f-year-max');
const sSort = qs('#f-sort'); const btnClear = qs('#clear');
let data = [], modelsByMake = new Map();

fetch('data/inventory.json').then(r=>r.json()).then(list => {
  data = list;
  const makes = [...new Set(list.map(v=>v.make))].sort();
  sMake.innerHTML = '<option value="">Any</option>' + makes.map(m=>`<option>${m}</option>`).join('');
  const bodies = [...new Set(list.map(v=>v.body_type))].sort();
  sBody.innerHTML += bodies.map(b=>`<option>${b}</option>`).join('');
  // map models
  makes.forEach(m => modelsByMake.set(m, [...new Set(list.filter(v=>v.make===m).map(v=>v.model))].sort()));
  sModel.innerHTML = '<option value="">Any</option>';
  render();
});

sMake.addEventListener('change', () => {
  const make = sMake.value;
  const models = make ? modelsByMake.get(make) : [];
  sModel.innerHTML = '<option value="">Any</option>' + (models||[]).map(m=>`<option>${m}</option>`).join('');
  render();
});
[sModel,sBody,nPriceMin,nPriceMax,nMileageMax,yMin,yMax,sSort].forEach(el=>el.addEventListener('input', render));
btnClear.addEventListener('click', () => {
  [sMake,sModel,sBody,sSort].forEach(el=>el.selectedIndex=0);
  [nPriceMin,nPriceMax,nMileageMax,yMin,yMax].forEach(el=>el.value='');
  render();
});

function render(){
  let list = data.slice();
  const make = sMake.value, model = sModel.value, body = sBody.value;
  const pmin = +nPriceMin.value||0, pmax = +nPriceMax.value||Infinity;
  const milmax = +nMileageMax.value||Infinity;
  const ymin = +yMin.value||0, ymax = +yMax.value||9999;

  list = list.filter(v =>
    (!make || v.make===make) &&
    (!model || v.model===model) &&
    (!body || v.body_type===body) &&
    (v.price>=pmin && v.price<=pmax) &&
    (v.mileage<=milmax) &&
    (v.year>=ymin && v.year<=ymax)
  );

  switch(sSort.value){
    case 'price-asc': list.sort((a,b)=>a.price-b.price); break;
    case 'price-desc': list.sort((a,b)=>b.price-a.price); break;
    case 'year-desc': list.sort((a,b)=>b.year-a-year); break;
    case 'mileage-asc': list.sort((a,b)=>a.mileage-b.mileage); break;
  }

  results.innerHTML='';
  if(!list.length){
    results.innerHTML = '<p class="small">No vehicles match your filters. Try clearing some options.</p>';
    return;
  }
  list.forEach(v => results.appendChild(window.cardForVehicle(v)));
}
