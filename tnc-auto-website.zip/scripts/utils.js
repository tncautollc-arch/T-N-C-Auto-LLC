
window.formatCurrency = (n) => n.toLocaleString(undefined,{style:'currency',currency:'USD',maximumFractionDigits:0});
window.comma = (n) => n.toLocaleString();
window.cardForVehicle = (v) => {
  const el = document.createElement('article');
  el.className = 'card';
  el.innerHTML = `
    <a href="vehicle.html?id=${encodeURIComponent(v.vin)}"><img src="${v.images?.[0] || 'assets/car1.svg'}" alt="${v.year} ${v.make} ${v.model}"></a>
    <div class="body">
      <h3><a href="vehicle.html?id=${encodeURIComponent(v.vin)}">${v.year} ${v.make} ${v.model}${v.trim?(' ' + v.trim):''}</a></h3>
      <div class="price">${formatCurrency(v.price)}</div>
      <div class="meta">${comma(v.mileage)} mi · ${v.body_type} · ${v.drivetrain}</div>
      <div class="tags">
        ${(v.features||[]).slice(0,3).map(f=>`<span class="tag">${f}</span>`).join('')}
      </div>
    </div>`;
  return el;
};
