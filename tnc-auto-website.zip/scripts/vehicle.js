
const params = new URLSearchParams(location.search);
const id = params.get('id');
const wrap = document.getElementById('vehicle');

fetch('data/inventory.json').then(r=>r.json()).then(list => {
  const v = list.find(x => x.vin === id) || list[0];
  document.title = `${v.year} ${v.make} ${v.model} — T N C Auto LLC`;

  const gallery = (v.images||[]).map(src => `<img src="${src}" alt="${v.year} ${v.make} ${v.model}">`).join('');
  const features = (v.features||[]).map(f=>`<span class="tag">${f}</span>`).join('');

  wrap.innerHTML = `
    <section class="gallery">${gallery}</section>
    <section class="specs">
      <h1>${v.year} ${v.make} ${v.model} ${v.trim||''}</h1>
      <div class="price">${formatCurrency(v.price)}</div>
      <p class="meta">${comma(v.mileage)} mi · ${v.body_type} · ${v.drivetrain} · ${v.transmission}</p>
      <p>${v.description||''}</p>
      <dl>
        <dt>VIN</dt><dd>${v.vin}</dd>
        <dt>Engine</dt><dd>${v.engine}</dd>
        <dt>Fuel</dt><dd>${v.fuel_type}</dd>
        <dt>Exterior</dt><dd>${v.exterior_color}</dd>
        <dt>Interior</dt><dd>${v.interior_color}</dd>
        <dt>MPG</dt><dd>${v.city_mpg}/${v.hwy_mpg}</dd>
        <dt>Location</dt><dd>${v.location||'On lot'}</dd>
      </dl>
      <h3>Features</h3>
      <div class="features">${features}</div>
      <div style="margin-top:1rem;display:flex;gap:.6rem;flex-wrap:wrap">
        <a class="btn primary" href="contact.html">Request availability</a>
        <a class="btn" href="tel:+14176645273">Call sales</a>
        <a class="btn" href="mailto:tncautollc@gmail.com">Email</a>
      </div>
      <p class="small">Price excludes tax, title, license, and doc fees. Subject to prior sale.</p>
    </section>`;

  // JSON-LD for this vehicle
  const ld = {
    "@context":"https://schema.org",
    "@type":"Vehicle",
    "name": `${v.year} ${v.make} ${v.model} ${v.trim||''}`.trim(),
    "vehicleIdentificationNumber": v.vin,
    "brand": {"@type":"Brand","name": v.make},
    "model": v.model,
    "vehicleEngine": v.engine,
    "fuelType": v.fuel_type,
    "bodyType": v.body_type,
    "mileageFromOdometer": {"@type":"QuantitativeValue","value": v.mileage, "unitCode":"SMI"},
    "offers": {"@type":"Offer","price": v.price, "priceCurrency":"USD", "availability":"https://schema.org/InStock"}
  };
  const s = document.createElement('script');
  s.type='application/ld+json';
  s.textContent = JSON.stringify(ld);
  document.head.appendChild(s);
});
